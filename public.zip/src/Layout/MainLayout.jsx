import React from 'react'
import Header from '../Pages/Header/Header'
import { Outlet } from "react-router-dom";
import Footer from '../Pages/Footer/Footer';
import CopyRight from '../Pages/Footer/CopyRight';

function MainLayout() {
  
  return (
    <>
      {/* <div className="d-flex flex-column min-vh-100"> */}
    <Header/>
    
    <Outlet/>

    <Footer/>
    {/* </div> */}
    {/* <CopyRight/> */}
    
    </>
  )
}

export default MainLayout