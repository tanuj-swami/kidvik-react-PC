// src/context/filterReducer.js

export const initialFilterState = {
  isLoading: false,
  isError: false,
  Listing_Data: [],
  filtered_Listing: [],
  sub_category: [],

  city_id: null,
  category_id: "all",
  sub_category_id: "all",
  sub_category_detail_id: "all",
  search: "",
  priceRange: [0, 1000],
  rating: 0,
};

export const filterReducer = (state, action) => {
  switch (action.type) {
    case "SET_LOADING":
      return { ...state, isLoading: action.payload };
    case "SET_ERROR":
      return { ...state, isError: action.payload };
    case "SET_LISTING_DATA":
      return { ...state, Listing_Data: action.payload };

case "SET_FILTER":
  // Decide which filter is changing
  const { name, value } = action.payload;

  // Always filter Listing_Data based on current category_id and new sub_category_id (or vice versa)
  let filtered = state.Listing_Data;

  // Apply category filter
  if (name === "category_id") {
    filtered = value === "all"
      ? state.Listing_Data
      : state.Listing_Data.filter(item => item.category_id === value);

    return {
      ...state,
      category_id: value,
      sub_category_id: "all",
      filtered_Listing: filtered
    };
  }

  // Apply subcategory filter
  if (name === "sub_category_id") {
    filtered = value === "all"
      ? state.Listing_Data.filter(item => 
          state.category_id === "all" ? true : item.category_id === state.category_id
        )
      : state.Listing_Data.filter(item =>
          item.sub_category_id === value
        );

    return {
      ...state,
      sub_category_id: value,
      filtered_Listing: filtered
    };
  }

  return state;


case "SET_CATEGORY":
  const filteredByCategory = state.Listing_Data.filter(
    (item) => action.payload === "all" || item.category?.id === action.payload
  );
  return {
    ...state,
    category_id: action.payload,
    sub_category_id: "all",
    filtered_Listing: filteredByCategory
  };


    case "SET_SUBCATEGORY":
      return { ...state, sub_category: action.payload };




    case "RESET_FILTERS":
      return initialFilterState;



    default:
      return state;



  }
};
