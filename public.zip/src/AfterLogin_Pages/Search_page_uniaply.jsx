import React, { useState  , useEffect} from 'react'
import "./Uniapply_design/Uniapply.css"
import { useAPI } from '../Contaxt/ALL_APi_Call/API_Call_Contaxt'
import { Link } from 'react-router-dom';
import CityLocationPicker from './Uniapply_design/SearchBar_City_option';
import styled from 'styled-components';
import { Use_Listing_Filter } from './Listing_contaxt/Listing_Contaxt';
import { Loading } from '../Helper/Loader';
import Filter_Listing from './Uniapply_design/Filter_Listing';
import { BASE_URL } from '../Helper/Base_Url';
import Search_page_card from './Uniapply_design/Search_page_card/Search_page_card';

function Search_page_uniaply() {
  // const { categories } = useAPI();
  const [activeCat, setActiveCat] = useState(null);
  
  const { state, category, loading, error, dispatch, } = Use_Listing_Filter();
  console.log("button", state.sub_category)
  
  return (
    <>
      <CityLocationPicker />
      <Wrapper>
        <div className="container-fluid px-4 py-2 category-bar">
          {error && (
            <div className="alert alert-danger text-center" role="alert">
              ❌ Failed to load categories. Please try again.
            </div>
          )}

          <ul className="nav justify-content-center">
            {
              loading ? <Loading /> : (
                category.map((cat, index) => (
                  <li className="nav-item fs-4" key={index}>
                    <Link
                      className={`nav-link ${activeCat === cat.id ? "active" : ""}`}
                      onClick={() => {
                        setActiveCat(cat.id);
                        dispatch({ type: "SET_CATEGORY", payload: cat.id });
                      }}
                    >
                      {cat.name}
                    </Link>
                  </li>
                ))
              )
            }
          </ul>
        </div>
      </Wrapper>


      <div className="container-fluid px-4 py-2  ">
        <nav aria-label="breadcrumb">
          <ol className="breadcrumb mb-0 me-auto">
            <li className="breadcrumb-item"><a href="#">Home</a></li>
            {/* <li className="breadcrumb-item active">Schools in Pune</li> */}
          </ol>
        </nav>
      </div>

      <div className="container-fluid px-4">
        <div className="row">
          {/* Left Sidebar - Filters */}

          <Filter_Listing />

          {/* Main Content Area */}
          <div className="col-lg-9 col-md-8">

            <div className="results-header d-flex justify-content-between align-items-center mb-4">
              <div className="d-flex align-items-center">
                {/* <h4 className="page-title mb-0">List of Schools in Pune</h4> */}
                <h4 className="page-title mb-0">
                  List of{" "}
                  {state.sub_category_id !== "all"
                    ? state.sub_category.find(sc => sc.value === state.sub_category_id)?.label || "Category"
                    : state.category_id !== "all"
                      ? category.find(c => c.id === state.category_id)?.name
                      : "Schools"}
                </h4>


                {/* <span className="results-count ms-3">773 Schools</span> */}
                <Result>
                  <span className="results-count ms-3">
                    <span className="badge bg-secondary">
                      {state.filtered_Listing.length}{" "}
                      {state.sub_category_id !== "all"
                        ? state.sub_category.find(sc => sc.value === state.sub_category_id)?.label || "Schools"
                        : state.category_id !== "all"
                          ? category.find(c => c.id === state.category_id)?.name
                          : "Schools"}{" "}
                      found
                    </span>
                  </span>
                </Result>



              </div>
              {/* Sort Dropdown */}
              <div className="sort-dropdown">
                <select className="form-select" id="sortBy">
                  <option value="relevance">Sort By: Relevance</option>
                  <option value="name">Name</option>
                  <option value="fee">Fee</option>
                  <option value="rating">Rating</option>
                </select>
              </div>
            </div>

            {/* School Type Filters */}
            <div className="school-type-filters mb-4">
              {state.sub_category.map((sub) => (<>
                <button
                  key={sub.value}
                  className={`btn school-type-btn d-flex align-items-center gap-2 ${state.sub_category_id === sub.value ? "active" : ""}`}
                  onClick={() =>
                    dispatch({
                      type: "SET_FILTER",
                      payload: { name: "sub_category_id", value: sub.value },
                    })
                  }
                >
                  <i className="fas fa-check me-1" />
                  {sub.img && (
                    <img
                      src={`${BASE_URL}${sub.img}`}
                      alt={sub.label}
                      style={{
                        height: "24px",
                        width: "24px",
                        objectFit: "contain",
                      }}
                    />
                  )}
                  <span>{sub.label}</span>
                </button>

              </>))}
            </div>
          <Search_page_card />
          </div>
        </div>
      </div>



    </>
  )
}


const Wrapper = styled.section`
.category-bar .nav-link {
  position: relative;
  color: #333;
  padding-bottom: 6px; /* thoda space underline ke liye */
  transition: color 0.2s;
}

.category-bar .nav-link::after {
  content: "";
  position: absolute;
  left: 0;
  bottom: 0;
  width: 0%;
  height: 3px;
  background-color: #42B682; /* underline color (red-ish) */
  transition: width 0.3s ease-in-out;
}

.category-bar .nav-link:hover {
  color: var(--bs-primary);
}

.category-bar .nav-link:hover::after {
  width: 100%;
}

.category-bar .nav-link.active {
  color: var(--bs-primary);
}

.category-bar .nav-link.active::after {
  width: 100%;
}





`
const Result = styled.div`
.results-count .badge {
  border-radius: 12px;
  padding: 4px 10px;
  font-size: 0.875rem;
}

`


export default Search_page_uniaply
