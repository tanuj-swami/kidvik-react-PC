import React from 'react'

function Filter_Listing() {
  return (
   <>
      <div className="col-lg-3 col-md-4">
            <div className="filters-sidebar">
              <h5 className="filters-title">Filters</h5>
              {/* Eligible Schools Filter */}
              <div className="filter-section">
                <button className="filter-toggle" data-bs-toggle="collapse" data-bs-target="#eligibleSchools">
                  <span>Eligible Schools</span>
                  <i className="fas fa-chevron-down" />
                </button>
                <div className="collapse" id="eligibleSchools">
                  <div className="filter-content">
                    {/* Filter options */}
                  </div>
                </div>
              </div>
              {/* Class Filter */}
              <div className="filter-section">
                <button className="filter-toggle" data-bs-toggle="collapse" data-bs-target="#classFilter">
                  <span>Class <i className="fas fa-info-circle text-muted ms-1" /></span>
                  <i className="fas fa-chevron-down" />
                </button>
                <div className="collapse" id="classFilter">
                  <div className="filter-content">
                    {/* Filter options */}
                  </div>
                </div>
              </div>
              {/* Academic Session Filter */}
              <div className="filter-section">
                <button className="filter-toggle" data-bs-toggle="collapse" data-bs-target="#academicSession">
                  <span>Academic Session</span>
                  <i className="fas fa-chevron-down" />
                </button>
                <div className="collapse" id="academicSession">
                  <div className="filter-content">
                    {/* Filter options */}
                  </div>
                </div>
              </div>
              {/* Fee Range Filter */}
              <div className="filter-section">
                <button className="filter-toggle" data-bs-toggle="collapse" data-bs-target="#feeRange">
                  <span>Monthly Fee Range</span>
                  <i className="fas fa-chevron-down" />
                </button>
                <div className="collapse" id="feeRange">
                  <div className="filter-content">
                    <div className="fee-range-slider">
                      <div className="d-flex justify-content-between mb-2">
                        <span>₹1</span>
                        <span>₹50000</span>
                      </div>
                      <input type="range" className="form-range" min={1} max={50000} defaultValue={25000} id="feeSlider" />
                    </div>
                  </div>
                </div>
              </div>
              {/* Other Filters */}
              <div className="filter-section">
                <button className="filter-toggle" data-bs-toggle="collapse" data-bs-target="#admissionPartner">
                  <span>Admission Partner</span>
                  <i className="fas fa-chevron-down" />
                </button>
                <div className="collapse" id="admissionPartner">
                  <div className="filter-content">
                    {/* Filter options */}
                  </div>
                </div>
              </div>
              <div className="filter-section">
                <button className="filter-toggle" data-bs-toggle="collapse" data-bs-target="#admissionProcess">
                  <span>Admission Process</span>
                  <i className="fas fa-chevron-down" />
                </button>
                <div className="collapse" id="admissionProcess">
                  <div className="filter-content">
                    {/* Filter options */}
                  </div>
                </div>
              </div>
              <div className="filter-section">
                <button className="filter-toggle" data-bs-toggle="collapse" data-bs-target="#boardFilter">
                  <span>Board</span>
                  <i className="fas fa-chevron-down" />
                </button>
                <div className="collapse" id="boardFilter">
                  <div className="filter-content">
                    {/* Filter options */}
                  </div>
                </div>
              </div>
              
              <div className="filter-section">
                <button className="filter-toggle" data-bs-toggle="collapse" data-bs-target="#popularAreas">
                  <span>Popular Areas</span>
                  <i className="fas fa-chevron-down" />
                </button>
                <div className="collapse" id="popularAreas">
                  <div className="filter-content">
                    {/* Filter options */}
                  </div>
                </div>
              </div>
            </div>
          </div>

   
   </>
  )
}

export default Filter_Listing
