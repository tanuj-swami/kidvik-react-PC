import React, { useEffect, useMemo, useRef, useState } from "react";
import Cityselecter from "./single_Page_listing/Cityselecter";
import { Search } from "lucide-react";
import { BASE_URL } from "../../Helper/Base_Url";

export default function CityLocationPicker() {
  const [cities, setCities] = useState([]);
  const popularIds = [2, 3, 4, 5];
  const defaultCityId = 1;
  const [selectedId, setSelectedId] = useState(defaultCityId);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const popoverRef = useRef(null);

  
  const selectedCity = useMemo(
    () => cities.find((c) => c.id === selectedId) ?? cities[0],
    [selectedId, cities]
  );

  console.log("selectedId", selectedId);
  console.log("Selected city:", selectedCity);

  const popular = useMemo(
    () => cities.filter((c) => popularIds.includes(c.id)),
    [cities, popularIds]
  );

  const others = useMemo(
    () => cities.filter((c) => !popularIds.includes(c.id)),
    [cities, popularIds]
  );

  // ✅ Fetch cities
  const fetchCities = async () => {
    try {
      const res = await fetch(`${BASE_URL}/city/?is_primary=1`);
      const data = await res.json();
      setCities(data.data || []);
    } catch (err) {
      console.error("Error fetching cities:", err);
    }
  };

  // ✅ On mount: fetch + read city from URL
  useEffect(() => {
    fetchCities();
    const params = new URLSearchParams(window.location.search);
    const cityId = params.get("city");
    if (cityId) {
      setSelectedId(Number(cityId));
    }
  }, []);

  // ✅ When selectedId changes → update URL (no reload)
  useEffect(() => {
    if (selectedId) {
      const params = new URLSearchParams(window.location.search);
      params.set("city", selectedId);
      const newUrl = `${window.location.pathname}?${params.toString()}`;
      window.history.replaceState({}, "", newUrl);
    }
  }, [selectedId]);

  // ✅ Close popover on outside click / Esc
  useEffect(() => {
    function handleClick(e) {
      if (open && popoverRef.current && !popoverRef.current.contains(e.target)) {
        setOpen(false);
      }
    }
    function onEsc(e) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", handleClick);
    document.addEventListener("keydown", onEsc);
    return () => {
      document.removeEventListener("mousedown", handleClick);
      document.removeEventListener("keydown", onEsc);
    };
  }, [open]);

 
  const submitSearch = (e) => {
    e.preventDefault();
    console.log("Search submitted:", query.trim(), selectedCity);
  };

  return (
    <div className="container" style={{ maxWidth: "900px" }}>
      <div className="row g-2 align-items-center bg-white border rounded shadow-sm p-2">

        {/* ✅ City Selector */}
        <Cityselecter
          cities={cities}
          popular={popular}
          others={others}
          selectedId={selectedId}
          setSelectedId={setSelectedId}
          selectedCity={selectedCity}
          open={open}
          setOpen={setOpen}
          query={query}
          setQuery={setQuery}
          popoverRef={popoverRef}
        />

        {/* ✅ Search Bar */}
        <div className="col-12 col-md-9">
          <form onSubmit={submitSearch} className="d-flex w-100">
            <input
              type="text"
              className="form-control"
              placeholder="Search Schools By Name..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <button
              className="btn btn-white ms-2 d-none d-md-inline"
              type="submit"
            >
              <Search size={16} />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
