import React from "react";
import { useLocation } from "react-router-dom";

function CompareListting() {
  // Get query params from URL
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const ids = params.get("ids");

  return (
    <div style={{ padding: "2rem" }}>
      <h2>Compare Schools</h2>
      <p>Selected School IDs: {ids ? ids : "None"}</p>
   
    </div>
  );
}

export default CompareListting;
