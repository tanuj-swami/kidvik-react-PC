import React from "react";
import { MapPin, ChevronDown, Crosshair, ChevronRight, ChevronLeft } from "lucide-react";
import { Use_Listing_Filter } from "../../Listing_contaxt/Listing_Contaxt";
import { BASE_URL } from "../../../Helper/Base_Url";

function Cityselecter({
  cities,
  selectedId,
  setSelectedId,
  selectedCity,
  open,
  setOpen,
  query,
  setQuery,
  popoverRef,
}) {
  const { Allcities } = Use_Listing_Filter();

  const [cityAreas, setCityAreas] = React.useState([]);
  const [loadingAreas, setLoadingAreas] = React.useState(false);
  const [activeCityId, setActiveCityId] = React.useState(null);
  const [cityName, setCityName] = React.useState("");

  // ✅ Fetch Areas
  const fetchCityAreas = async (cityId) => {
    try {
      setLoadingAreas(true);
      setActiveCityId(cityId);
      const res = await fetch(
        `${BASE_URL}/location_mst/?city_id=${cityId}&is_primary=1`
      );
      if (!res.ok) throw new Error("Failed to fetch areas");
      const data = await res.json();
      setCityAreas(data.data || []);
    } catch (err) {
      console.error(err);
      setCityAreas([]);
    } finally {
      setLoadingAreas(false);
    }
  };

  // ✅ Back to cities
  const handleBack = () => {
    setActiveCityId(null);
    setCityAreas([]);
  };

  return (
    <div className="col-12 col-md-3">
      {/* Main button */}
      <button
        type="button"
        className="btn btn-white w-100 d-flex align-items-center justify-content-between"
        onClick={() => setOpen(!open)}
      >
        <div className="d-flex align-items-center">
          <MapPin size={16} className="text-danger me-2" />
          <span>{ selectedCity?.City_name || "Select City"}</span>
        </div>
        <ChevronDown size={16} className="ms-2 text-secondary" />
      </button>

      {/* Popover */}
      {open && (
        <div
          ref={popoverRef}
          className="card_1 shadow position-absolute p-3 mt-1 w-90"
          style={{ zIndex: 1050, maxHeight: "70vh", overflowY: "auto" }}
        >
          {/* Search Input */}
          <div className="d-flex flex-column flex-sm-row mb-3 gap-2">
            <input
              type="text"
              className="form-control"
              placeholder="Search Location, City..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />

            <button className="btn btn-outline-danger d-flex align-items-center">
              <Crosshair size={16} className="me-1" />
              <span className="small">Detect</span>
            </button>
          </div>

          {/* Cities List */}
          {!activeCityId && (
            <>
              <h6 className="fw-semibold">Popular Locations</h6>
              <div className="row row-cols-1 row-cols-sm-2 g-2 mb-3">
                {cities.map((p) => (
                  <div key={p.id}>
                    <div className="d-flex justify-content-between align-items-center">
                      <button
                        className={`btn w-100 d-flex justify-content-between align-items-center border ${
                          selectedId === p.id ? "text-white bg-primary" : "text-dark"
                        }`}
                        onClick={() => {
                          setSelectedId(p.id);
                          setOpen(false);
                        }}
                      >
                        {p.City_name}
                        {/* ChevronRight */}
                        <button
                          className="btn d-flex align-items-center justify-content-center p-1 ms-2"
                          style={{
                            width: "36px",
                            height: "36px",
                            borderRadius: "50%",
                            border: "1px solid #42B682",
                            backgroundColor: "#fff",
                            color: "#42B682",
                          }}
                          onClick={(e) => {
                            e.stopPropagation();
                            fetchCityAreas(p.id);
                            setCityName(p.City_name);
                          }}
                        >
                          <ChevronRight size={20} />
                        </button>
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <h6 className="fw-semibold">Other Locations ({Allcities.length})</h6>
              <div
                className="d-flex flex-column gap-1 p-2 border rounded"
                style={{ maxHeight: "300px", overflowY: "auto" }}
              >
                {Allcities.map((o) => (
                  <div key={o.id} className="d-flex justify-content-between align-items-center">
                    <button
                      className={`btn w-100 d-flex justify-content-between align-items-center border ${
                        selectedId === o.id ? "text-white bg-primary" : "text-dark"
                      }`}
                      onClick={() => {
                        setSelectedId(o.id);
                        setOpen(false);
                      }}
                    >
                      {o.City_name}
                      <button
                        type="button"
                        className="btn d-flex align-items-center justify-content-center p-1 ms-2"
                        style={{
                          width: "36px",
                          height: "36px",
                          borderRadius: "50%",
                          border: "1px solid #42B682",
                          backgroundColor: "#fff",
                          color: "#42B682",
                        }}
                        onClick={(e) => {
                          e.stopPropagation();
                          fetchCityAreas(o.id);
                          setCityName(o.City_name);
                        }}
                      >
                        <ChevronRight size={20} />
                      </button>
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Areas List */}
          {activeCityId && (
            <div>
              <div className="d-flex align-items-center mb-2">
                <div className="me-2" onClick={handleBack} style={{ cursor: "pointer" }}>
                  <ChevronLeft size={20} /> Back
                </div>
                <h6 className="fw-semibold mb-0">Popular Areas in {cityName}</h6>
              </div>

              <div
                className="d-flex flex-column gap-1 p-2 border rounded"
                style={{ maxHeight: "300px", overflowY: "auto" }}
              >
                {loadingAreas ? (
                  <span>Loading areas...</span>
                ) : cityAreas.length > 0 ? (
                  cityAreas.map((area) => (
                    <button
                      key={area.id}
                      className="btn btn-sm text-start w-100 fs-6 fw-bold"
                      onClick={() => {
                        console.log("Selected area:", area);
                      }}
                    >
                      {area.Location_name}
                    </button>
                  ))
                ) : (
                  <span>No areas found</span>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default Cityselecter;
