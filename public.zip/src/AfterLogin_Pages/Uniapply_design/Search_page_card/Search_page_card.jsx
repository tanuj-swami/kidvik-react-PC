import React, { useState, useEffect } from "react";
import styled, { keyframes } from "styled-components";
import { BASE_URL } from "../../../Helper/Base_Url";
import { Use_Listing_Filter } from "../../Listing_contaxt/Listing_Contaxt";
import { showToast } from "../../../Helper/toastService";
import { Link, useNavigate , NavLink } from "react-router-dom";

function Search_page_card() {
  const navigate = useNavigate();
  const { state } = Use_Listing_Filter();
  const [compareList, setCompareList] = useState([]);
  const [hover, setHover] = useState(false);
  const [categoryName, setCategoryName] = useState("");
  // Load from sessionStorage
  useEffect(() => {
    const stored = JSON.parse(sessionStorage.getItem("compareSchools")) || [];
    setCompareList(stored);
  }, []);

  // Save to sessionStorage
  useEffect(() => {
    sessionStorage.setItem("compareSchools", JSON.stringify(compareList));
  }, [compareList]);

  const handleCompareToggle = (partner_id, category_name) => {
    setCategoryName(category_name);
    setCompareList((prev) => {
      if (prev.includes(partner_id)) {
        return prev.filter((id) => id !== partner_id);
      } else {
        if (prev.length >= 4) {
          showToast(`You can only compare up to 4 ${categoryName ? categoryName : "listings"}!`, "error");
          return prev;
        }
        showToast(`${categoryName ? categoryName : "listing"} added to compare`, "success");
        return [...prev, partner_id];
      }
    });
  };

  const removeSchool = (id) => {
    setCompareList((prev) => prev.filter((x) => x !== id));
    showToast("School removed", "success");
  };

  const clearAll = () => {
    setCompareList([]);
    showToast("Cleared all", "success");
  };

  const selectedSchools = state.filtered_Listing.filter((s) =>
    compareList.includes(s.PartnerMaster_id)
  );



  return (
    <>
      <Card>
        <div className="school-listings">
          {state.filtered_Listing.map((list) => (
            <div
              className="school-card p-3 mb-3"
              key={list.PartnerMaster_id}
            >
              {/* Image */}

              <div className="school-image-container">
                <img
                  src={
                    list?.logo
                      ? `${BASE_URL}${list.logo}`
                      : "/img/logo/Kidvik_Final_logo01.jpg.png"
                  }
                  alt={list.listing_name}
                  className="school-image"
                />
                <span className="status-badge">On Going</span>
              </div>

              {/* Details */}
              <div className="school-details flex-grow-1">
                <NavLink to={`/partner/${list.slug}`}>
                <div className="d-flex align-items-start justify-content-between mb-2">
                  <h5 className="school-name mb-0">{list.listing_name}</h5>
                </div>
                <div className="d-flex align-items-center gap-2">
                  <span className="likes text-muted">
                    <i className="fas fa-heart text-danger me-1" />
                    {list.likes || 0}
                  </span>
                  {!list.isAdmissionPartner && (
                    <span className="badge bg-light text-dark">
                      <i className="fas fa-handshake me-1" /> Admission Partner
                    </span>
                  )}
                </div>

                {/* Location */}
                <div className="school-location text-muted mb-2">
                  <i className="fas fa-map-marker-alt text-danger me-1" />
                  {list?.area?.Location_name || "Unknown Area"},{" "}
                  {list?.city?.City_name || "Unknown City"}
                </div>

                {/* Info grid */}
                <div className="row mb-3">
                  <div className="col-6 col-lg-3">
                    <strong>Classes: </strong>
                    {list?.sub_category?.name || "Pre-Nursery - 10"}
                  </div>
                  <div className="col-6 col-lg-3">
                    <strong>Fees: </strong>₹{list?.fee || "10.6K"}
                  </div>
                  <div className="col-6 col-lg-3">
                    <strong>Board: </strong> CBSE
                  </div>
                  <div className="col-6 col-lg-3">
                    <strong>Ratio: </strong> 24:1
                  </div>
                </div>
               </NavLink>
                {/* Actions */}
                <div className="d-flex align-items-center justify-content-end gap-3">
                  <div className="form-check m-0 d-flex align-items-center">
                    <input
                      type="checkbox"
                      className="form-check-input me-2 compare-checkbox"
                      id={`compare-${list.PartnerMaster_id}`}
                      checked={compareList.includes(list.PartnerMaster_id)}
                      onChange={() => handleCompareToggle(list.PartnerMaster_id, list?.category?.name)}
                    />
                    <label
                      htmlFor={`compare-${list.PartnerMaster_id}`}
                      className="form-check-label"
                    >
                        Compare
                    </label>
                  </div>
                  <NavLink to={`/partner/${list.slug}`}>
                  <button className="custom-btn btn-sm">
                     View Details
                  </button>
                  </NavLink>

                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>


      {selectedSchools.length > 0 && (
        <>
          <Overlay open={hover} onMouseLeave={() => setHover(false)} />
          <CompareBar>
            <div
              className="compare-box"
              onMouseEnter={() => setHover(true)}
              onMouseLeave={() => setHover(false)}
            >
              <Link to={`/compare/?ids=${selectedSchools.map(s => s.PartnerMaster_id).join(",")}`}>

                <button className="compare-btn"    >
                  COMPARE <span > {selectedSchools.length}</span>
                </button>
              </Link>

              {hover && (
                <div className="schools-tooltip">
                  <div className="schools">
                    {selectedSchools.map((school) => (
                      <div
                        className="school-card-mini"
                        key={school.PartnerMaster_id}
                      >
                        <div className="img-wrap">
                          <img
                            src={
                              school?.logo
                                ? `${BASE_URL}${school.logo}`
                                : "/img/logo/Kidvik_Final_logo01.jpg.png"
                            }
                            alt={school.listing_name}
                          />
                          <button
                            className="remove"
                            onClick={() => removeSchool(school.PartnerMaster_id)}
                          >
                            ✕
                          </button>
                        </div>
                        <p className="name">{school.listing_name}</p>
                        <p className="location">
                          {school?.area?.Location_name || "Unknown Area"},{" "}
                          {school?.city?.City_name || "Unknown City"}
                        </p>
                      </div>
                    ))}
                  </div>
                  <div className="actions">
                    <button className="clear" onClick={clearAll}>
                      Clear All
                    </button>
                    <Link to={`/compare/?ids=${selectedSchools.map(s => s.PartnerMaster_id).join(",")}`}>
                      <button className="compare-btn" >
                        COMPARE <span > {selectedSchools.length}</span>
                      </button>
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </CompareBar>
        </>
      )}
    </>
  );
}

export default Search_page_card;
const Card = styled.section`
  .school-card {
    background: #fff;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    display: flex;
    flex-direction: column;
    gap: 16px;
    transition: all 0.3s ease;
  }
  @media (min-width: 768px) {
    .school-card {
      flex-direction: row;
      align-items: center;
    }
  }
    .custom-btn {
  border-radius: 8px;
  background: white;
  color: black;
  border: 1px solid #42B682;
  transition: all 0.3s ease;
}

.custom-btn:hover {
  background: #42B682; 
  color: white;
  border-color: #42B682;
}

  .school-card:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    border-color: #007bff;
  }
  .school-image-container {
    position: relative;
    width: 160px;
    height: 120px;
    flex-shrink: 0;
    border-radius: 8px;
    overflow: hidden;
  }
  .school-image {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }
  .status-badge {
    position: absolute;
    top: 8px;
    left: 8px;
    background: #28a745;
    color: white;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
  }
  .school-name {
    font-weight: 600;
    font-size: 18px;
    color: #333;
     text-transform: capitalize;
}
  }
  .school-location {
    font-size: 14px;
    color: #666;
  }
  .compare-checkbox {
    transform: scale(1.2);
    cursor: pointer;
  }
`;


const slideIn = keyframes`
  from { transform: translateY(50px); opacity: 0; }
  to { transform: translateY(0); opacity: 1; }
`;

const Overlay = styled.div`
  position: fixed;
  top: 0; left: 0;
  width: 100vw; height: 100vh;
  background: rgba(0,0,0,0.5);
  z-index: 10000;
  display: ${({ open }) => (open ? "block" : "none")};
`;

const CompareBar = styled.div`
  position: fixed;
  bottom: 20px; right: 20px;
  z-index: 10001;

  .compare-box { position: relative; display: inline-block; }

  .compare-btn {
    background: #0056b3;
    color: #fff;
    border: none;
    padding: 10px 16px;
    border-radius: 6px;
    font-weight: bold;
    display: flex; align-items: center; gap: 6px;
  }
  .compare-btn span {
    background: #fff; color: #0056b3;
    font-weight: bold; padding: 2px 6px;
    border-radius: 50%; font-size: 12px;
  }

  .schools-tooltip {
    position: absolute; bottom: 45px; right: 0;
    background: #fff;
    border-radius: 10px;
    padding: 12px;
    min-width: 250px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    animation: ${slideIn} 0.3s ease;
  }
  .schools { display: flex; gap: 12px; overflow-x: auto; }
  .school-card-mini {
    flex: 0 0 auto; width: 140px;
    background: #f8f9fa; border: 1px solid #eee;
    border-radius: 6px; padding: 6px; font-size: 12px;
  }
  .img-wrap { position: relative; height: 70px; overflow: hidden; }
  .img-wrap img { width: 100%; height: 100%; object-fit: cover; }
  .remove {
    position: absolute; top: 4px; right: 4px;
    background: red; color: #fff;
    border-radius: 50%; font-size: 12px;
    width: 18px; height: 18px; border: none;
  }
  .actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 8px; }
  .clear { border: none; background: transparent; color: red; cursor: pointer; }
`;
