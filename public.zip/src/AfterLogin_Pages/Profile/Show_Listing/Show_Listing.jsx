import React, { useEffect, useState } from "react";
import { Spinner, Alert, Container, Badge  ,  InputGroup,FormControl,} from "react-bootstrap";
import { BASE_URL } from "../../../Helper/Base_Url";
import { usePartnerLogin } from "../../../Contaxt/PartnarLogin_context";
import { FaEdit, FaEye , FaSearch } from "react-icons/fa";
import { useNavigate, useLocation, NavLink } from "react-router-dom";
import DataTable from "react-data-table-component";

function Show_Listing() {
  const [listings, setListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filteredListings, setFilteredListings] = useState([]); // filtered data
  const [error, setError] = useState("");
  const { partnerAuth } = usePartnerLogin();
  const [searchTerm, setSearchTerm] = useState(""); // ✅ search input value
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (location.hash === "#partner-listings") {
      const element = document.getElementById("partner-listings");
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
  }, [location]);


   useEffect(() => {
    if (!searchTerm) {
      setFilteredListings(listings);
    } else {
      const lowerSearch = searchTerm.toLowerCase();
      const filtered = listings.filter((item) =>
        Object.values(item).some((val) =>
          String(val).toLowerCase().includes(lowerSearch)
        )
      );
      setFilteredListings(filtered);
    }
  }, [searchTerm, listings]);


  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(
          `${BASE_URL}/partner_master/?created_user_id=${partnerAuth.user_id}`
        );
        const data = await res.json();
        if (data && data.data) {
          setListings(data.data);
          setFilteredListings(data.data); 
        } else {
          setError("No listings available");
        }
      } catch (err) {
        setError("Something went wrong while fetching data.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleEdit = (id) => {
    navigate(`/park_listing/${id}`);
  };

  const handleviwe = (slug) => {
    navigate(`/partner/${slug}`);
  };

  // ✅ Define DataTable columns
  const columns = [
    {
      name: "Action",
      cell: (row) => (
        <div className="d-flex gap-2">
          <button
            className="btn-sm"
            onClick={() => handleEdit(row.PartnerMaster_id)}
          >
            <FaEdit /> 
          </button>
          <button
            className=" btn-sm"
            onClick={() => handleviwe( row?.slug == "" || null ? row.PartnerMaster_id : row.slug)}
          >
            <FaEye />
          </button>
        </div>
      ),
      ignoreRowClick: true,
      allowOverflow: true,
      button: true,
    },
  {
      name: "Status",
      cell: (row) => (
        <span
          style={{
            backgroundColor:
              row?.park_status?.ParkStatus_name === "Parked"
                ? "#d3bd9aff"
                : row?.park_status?.ParkStatus_name === "Temporarily"
                ? "#b7d0e2ff"
                : row?.park_status?.ParkStatus_name === "Live"
                ? "#abe2b0ff"
                : row?.park_status?.ParkStatus_name === "Block"
                ? "#df909eff"
                : "white",
            color:
              row?.park_status?.ParkStatus_name === "Parked"
                ? "orange"
                : row?.park_status?.ParkStatus_name === "Temporarily"
                ? "blue"
                : row?.park_status?.ParkStatus_name === "Live"
                ? "green"
                : row?.park_status?.ParkStatus_name === "Block"
                ? "red"
                : "black",
            fontWeight: "600",
            padding: "4px 10px",
            borderRadius: "6px",
          }}
        >
          {row?.park_status?.ParkStatus_name}
        </span>
      ),
      sortable: true,
    },

{
  name: "Partner ID",
  selector: (row) => row?.PartnerMaster_id || "-",
  sortable: true,
  cell: (row) => (
    <span
      style={{ cursor: "pointer", color: "#0d6efd" }}
      onClick={() => handleviwe(row?.slug ? row.slug : row.PartnerMaster_id)}
    >
      {row?.PartnerMaster_id || "-"}
    </span>
  ),
},

    { name: "Category", selector: (row) => row?.category?.name || "-", sortable: true },
    { name: "Sub Category", selector: (row) => row?.sub_category?.name || "-", sortable: true },
    { name: "Detail", selector: (row) => row?.sub_category_detail?.name || "-", sortable: true },
    { name: "Listing Name", selector: (row) => row?.listing_name || "-", sortable: true },
    { name: "City", selector: (row) => row?.city?.City_name || "-", sortable: true },
    {
      name: "Address",
      selector: (row) => `${row?.address_1 || ""}, ${row?.address_2 || ""}, Pincode: ${row?.pincode || ""}`,
      wrap: true,
    },
    {
      name: "Contact",
      selector: (row) =>
        `${row?.list_mobno || row?.person_mobile_number || "-"} | WhatsApp: ${row?.whats_up || "-"}`,
      wrap: true,
    },
    { name: "Email", selector: (row) => row?.list_email || row?.person_email || "-", sortable: true },
    {
      name: "Website",
      cell: (row) =>
        row?.website ? (
          <a href={row.website} target="_blank" rel="noreferrer" className="text-primary">
            Visit Site
          </a>
        ) : (
          "-"
        ),
    },
  
    { name: "Remark", selector: (row) => row?.remark || "-", wrap: true },
   
  ];

  return (
    <Container id="partner-listings" className="mt-4 bg-light py-5">
      {/* <h3 className="mb-4 text-primary d-flex align-items-center justify-content-between">
        Partner Listings
          <input
              type="text"
              placeholder="Search..."
              className="form-control w-25"
              onChange={(e) => {
                const searchText = e.target.value.toLowerCase();
                setListings((prev) =>
                  prev.filter((item) =>
                    item?.listing_name?.toLowerCase().includes(searchText)
                  )
                );
              }}
            />
        <NavLink to="/park_listing" className="btn btn-success">
          + Create Listing
        </NavLink>
     
      </h3>
      <hr></hr> */}
        <div className="d-flex align-items-center gap-3">
         <NavLink to="/park_listing" className="btn btn-success">
          + Create Listing
        </NavLink>
        
       <InputGroup style={{ maxWidth: "500px" }}>
          <InputGroup.Text>
            <FaSearch className="text-secondary" />
          </InputGroup.Text>

          <FormControl
            type="text"
            placeholder="Search listings..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />

        </InputGroup>
      
                    <span className="ms-auto fw-bold text-primary">
          Total Listings: {filteredListings.length} / {listings.length}
        </span>
                </div>

      
      {loading ? (
        <div className="text-center">
          <Spinner animation="border" role="status" />
          <p className="mt-2">Loading listings...</p>
        </div>
      ) : error ? (
        <Alert variant="warning" className="text-center">
          {error}
        </Alert>
      ) : listings.length === 0 ? (
        <Alert variant="info" className="text-center">
          No listings available
        </Alert>
      ) : (
        <DataTable
          columns={columns}
          data={filteredListings}
          pagination
          highlightOnHover
          striped
          responsive
          defaultSortFieldId={1}
          subHeader
         customStyles={{
              headCells: {
                style: {
                  backgroundColor: "#68c597ff",
                  color: "white",
                  fontWeight: "bold",
                  fontSize: "14px",
                },
              },
            }}
        />
      )}
    </Container>
  );
}

export default Show_Listing;
