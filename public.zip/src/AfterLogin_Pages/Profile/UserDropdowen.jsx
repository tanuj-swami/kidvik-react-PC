import React from "react";
import { FaUserCircle, FaSignOutAlt, FaChevronDown  , FaPlusCircle, FaListAlt, FaCheckCircle} from "react-icons/fa";
import { Dropdown } from "react-bootstrap";
import { Link, NavLink } from "react-router-dom";
import { useLogin } from "../../Contaxt/Login_Contaxt";
import { usePartnerLogin } from "../../Contaxt/PartnarLogin_context";
import ButtonLoading from "../../Helper/ButtonLoading";

function UserDropdown() {
  const { auth, logout } = useLogin();
  const { partnerAuth , partnerLogout, Loading } = usePartnerLogin();

  const username = auth?.username || partnerAuth?.partnerUsername;
  const accessType = partnerAuth?.accesstypename || partnerAuth?.userType;

  return (
    <div className="position-relative">
      <Dropdown align="end">
        {/* Profile Button */}
        <Dropdown.Toggle
          variant="light"
          className="d-flex align-items-center bg-white border rounded-pill shadow-sm px-2 py-1"
        >
          <img
            src="/img/kidvik_school_img/user_image.jpg"
            alt="user"
            className="rounded-circle me-2"
            width="40"
            height="40"
          />
          <h5 className="fw-bold d-none d-md-inline">{`Hey ${ username ? username : 'Guest'}`}</h5>
          <FaChevronDown className="ms-2 text-muted small" />
        </Dropdown.Toggle>

        {/* Dropdown Menu */} 
        <Dropdown.Menu
          className="p-3 shadow border-2 bg-light"
          style={{ borderRadius: "12px", minWidth: "300px" }}
        >
          {/* User Info */}
          <div className="text-center mb-3">
            <img
              src="/img/kidvik_school_img/user_image.jpg"
              alt="User"
              className="rounded-circle border shadow-sm"
              width="80"
              height="80"
            />
            {/* <h5 className="mt-2 mb-0 fw-bold">{`Hey ${ username ? username : 'Guest'}`}</h5> */}
            <h5 className="text-muted fw-bold">{accessType} -&nbsp; <span>{partnerAuth?.userTypename} </span></h5>
            {/* <h6 className="text-muted fw-bold" style={{display:'inline'}}>{accessType}</h6> */}
          </div>

          <hr />

          {/* Partner Zone Links */}
          {(partnerAuth?.code === "AD" ||
            partnerAuth?.userType === "IH" ||
            partnerAuth?.userType === "PR") && (
            <>
              <p className="fw-bold text-muted small mb-2">Partner Zone</p>
              <div className="d-flex flex-column gap-2 mb-3">
                {partnerAuth?.code === "AD" ? (
                  <>
                    <Link to="/park_listing" className="dropdown-item rounded d-flex align-items-center gap-2">
  <FaPlusCircle className="text-primary" /> Create Listing
</Link>

<Link to="/Profile#partner-listings" className="dropdown-item rounded d-flex align-items-center gap-2">
  <FaListAlt className="text-primary" /> View My Listings
</Link>

<Link to="/listing_approved" className="dropdown-item rounded d-flex align-items-center gap-2">
  <FaCheckCircle className="text-success" /> Approved Listings
</Link>

                  </>
                ) : (
                  <>
                    <Link to="/park_listing" className="dropdown-item rounded">
                      ➕ Create Listing
                    </Link>
                    <Link
                      to="/Profile#partner-listings"
                      className="dropdown-item rounded"
                    >
                      📋 View My Listings
                    </Link>
                  </>
                )}
              </div>
              <hr />
            </>
          )}

          {/* Actions */}
          <div className="d-flex gap-2">
            <NavLink to="Profile" className="w-50 text-decoration-none">
              <button className="btn btn-primary w-100 d-flex align-items-center justify-content-center rounded-pill">
                <FaUserCircle className="me-1" />
                Profile
              </button>
            </NavLink>

            <button
              className="btn btn-primary w-50 d-flex align-items-center justify-content-center rounded-pill"
              onClick={auth?.username ? logout : partnerLogout}
              disabled={Loading}
            >
              <FaSignOutAlt className="me-1" />
              {Loading ? (
                <>
                  <ButtonLoading /> Logout...
                </>
              ) : (
                "Logout"
              )}
            </button>
          </div>
        </Dropdown.Menu>
      </Dropdown>
    </div>
  );
}

export default UserDropdown;
