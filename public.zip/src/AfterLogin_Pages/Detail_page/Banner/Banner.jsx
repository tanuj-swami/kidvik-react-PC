import React from 'react'
import { motion } from "framer-motion";
import { FaStar } from "react-icons/fa";
import { useAPI } from '../../../Contaxt/ALL_APi_Call/API_Call_Contaxt';
import { BASE_URL } from '../../../Helper/Base_Url';

function Banner({singledetail}) {

  return (
    <>
<section className="hero"  style={{
    backgroundImage: `url(${
      singledetail?.banner_img
        ? `${BASE_URL}${singledetail.banner_img}`
        : "/img/logo/Kidvik_Final_logo01.jpg.png"
    })`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  }}>

  <div className="hero-overlay ">
    <div className="hero-content">

    <div className="school-header"> 
    <div className="partner-logo">
      <img
        src={ singledetail?.logo ? `${BASE_URL}${singledetail?.logo}` : '/img/logo/Kidvik_Final_logo01.jpg.png'}
        alt="Partner logo"
        className="partner-logo-img"
        loading="lazy"
      />
    </div>
    <div>

    <h1 className="school-name">{singledetail?.listing_name}</h1>
       {singledetail?.Tag_Line && (
         <p className="text-gray-500 italic">“{singledetail.Tag_Line}”</p>
        )}
        </div>

  </div>
   

      <div className="school-location">
        <i className="fas fa-map-marker-alt" />
        <span>{singledetail?.address_1}</span>
      </div>

      <div className="rating">
        <div className="stars">
          <i className="fas fa-star" />
          <i className="fas fa-star" />
          <i className="fas fa-star" />
          <i className="fas fa-star" />
          <i className="fas fa-star-half-alt" />
        </div>
        <span>4.7/5 - 128 reviews</span>
      </div>
      
    </div>
     
    
  </div>
 {/* <div className='parner_logo '>
        <img src="/img/logo/Kidvik_Final_logo01.jpg.png" alt="" className='parner_logo_img' />
      </div> */}
</section>

    {/* <motion.header
        className="school-header"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        style={{
          backgroundImage: "url('/images/school-bg.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          color: "white",
          padding: "60px 20px",
          position: "relative",
        }}
      >
        <div className="overlay"></div>
        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          Sunshine Montessori School
        </motion.h1>
        <motion.p
          className="address"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          123 Education Lane, Boston, MA
        </motion.p>
        <motion.div
          className="rating"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
        >
          <FaStar className="star-icon" />
          <span className="rating-value">4.7/5</span>
          <a href="#reviews" className="review-count">(128 reviews)</a>
        </motion.div>
      </motion.header> */}
    </>
  )
}

export default Banner;
