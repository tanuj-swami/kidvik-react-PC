import React from 'react'

function Home_New() {
  return (
   <>
   <h>Welcome To Kidvik.com</h>
   
   </>
  )
}

export default Home_New