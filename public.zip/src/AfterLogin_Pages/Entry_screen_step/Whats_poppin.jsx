import React from 'react'

function Whats_poppin() {
  return (
    <div>
      <h1>Whats_poppin</h1>
    </div>
  )
}

export default Whats_poppin
