// src/utils/toastService.js
import { toast } from "react-toastify";

export const showToast = (message, type = "success") => {
  switch (type) {
    case "success":
      toast.success(message || "Success");
      break;
    case "error":
      toast.error(message || "Something went wrong ❌");
      break;
    case "warning":
      toast.warning(message || "Warning ⚠️");
      break;
    case "info":
      toast.info(message || "Info ℹ️");
      break;
    default:
      toast(message);
  }
};
