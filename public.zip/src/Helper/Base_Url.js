
// export const  BASE_URL = `https://api.kidvik.com`;

export const  BASE_URL = `https://dec.kidvik.com`;