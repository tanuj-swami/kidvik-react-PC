import React from 'react'

function ButtonLoading() {
  return (
    <>
    
    <span
      className={`spinner-border spinner-border-sm text-white`}
      role="status"
    ></span>

    
    
    </>
  )
}

export default ButtonLoading