export const CONTACT_INFO = {
  whatsappNumber: "919413561917", 
  email: "yourname@example.com",
  Mobile_Number :"+91 9413561917"

};
