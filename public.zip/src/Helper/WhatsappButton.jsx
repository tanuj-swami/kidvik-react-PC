import React from "react";
import { FaWhatsapp } from "react-icons/fa";
import "../Helper/Whatsapp_Button.css";
import { CONTACT_INFO } from "./Mobile_Number";

function WhatsappButton() {
  return (
    <a
      href={`https://wa.me/${CONTACT_INFO.whatsappNumber}`} // replace with your number
      target="_blank"
      rel="noopener noreferrer"
      className="whatsapp-button"
    >
      <FaWhatsapp size={30} />
    </a>
  );
}

export default WhatsappButton;
