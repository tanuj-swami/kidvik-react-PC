// src/components/common/Form_input.js
import React from "react";
import { Form } from "react-bootstrap";

function Form_input({
  label,
  name,
  type = "text",
  value,
  onChange,
  placeholder,
  options = [],
  required = false,
  maxLength,
  minLength,
  error,
  readOnly = false,
  step,
  min,
  max,
}) {
  const showCounter =
    (type === "textarea" || type === "text") && maxLength;

  // ✅ URL validation (accepts https://, http://, or www.)
  const isUrlValid =
    type === "url" && value
      ? /^(https?:\/\/|www\.)[^\s/$.?#].[^\s]*$/i.test(value)
      : true;

  const isPincodeValid =
    name === "pincode" && value ? /^\d{6}$/.test(value) : true;

  // ✅ Handle input change + auto-correct www → https://
  const handleInputChange = (e) => {
    let { name, value } = e.target;

    if (type === "url" && value && /^www\./i.test(value)) {
      value = `https://${value}`;
    }

    onChange({ target: { name, value } });
  };

  return (
    <Form.Group className="mb-3 d-flex flex-column" controlId={name}>
      {type === "checkbox" ? (
        // ✅ Checkbox
        <Form.Check
          type="checkbox"
          id={name}
          label={<span className="fw-bold text-black fs-5">{label}</span>}
          name={name}
          checked={!!value}
          onChange={(e) =>
            onChange({
              target: { name, value: e.target.checked },
            })
          }
        />
      ) : type === "select" ? (
        // ✅ Select Dropdown
        <>
          <Form.Label className="text-black fw-bold fs-5">
            {label} {required && <span className="text-danger">*</span>}
          </Form.Label>

          <Form.Select name={name} value={value} onChange={onChange}>
            <option value="">Select {label}</option>
            {options.map((opt, idx) => (
              <option key={idx} value={opt}>
                {opt}
              </option>
            ))}
          </Form.Select>

          {error && <small className="text-danger">{error}</small>}
        </>
      ) : type === "textarea" ? (
        // ✅ Textarea
        <>
          <Form.Label className="text-black fw-bold fs-5">
            {label} {required && <span className="text-danger">*</span>}
          </Form.Label>
          <Form.Control
            as="textarea"
            rows={3}
            name={name}
            value={value}
            onChange={onChange}
            placeholder={`Enter ${label}...`}
            maxLength={maxLength}
            required={required}
            readOnly={readOnly}
          />
          {showCounter && (
            <div className="d-flex justify-content-between">
              <small className="text-muted">
                {value?.length || 0}/{maxLength}
              </small>
              {value?.length >= maxLength && (
                <small className="text-danger">
                  Max {maxLength} characters allowed
                </small>
              )}
            </div>
          )}
          {error && <small className="text-danger">{error}</small>}
        </>
      ) : (
        // ✅ All other inputs (text, url, number, file, etc.)
        <>
          <Form.Label className="text-black fw-bold fs-5">
            {label} {required && <span className="text-danger">*</span>}
          </Form.Label>

          <Form.Control
            type={type}
            className={`text-dark form-control ${error ? "is-invalid" : ""}`}
            name={name}
            value={type === "file" ? undefined : value}
            onChange={handleInputChange}

            placeholder={
              placeholder ||
              (type === "url"
                ? "Enter website (e.g. https://example.com or www.example.com)"
                : `Enter ${label}...`)
            }
            accept={type === "file" ? "image/*" : undefined}
            minLength={minLength}
            maxLength={maxLength}
            required={required}
            pattern={
              name === "pincode"
                ? "\\d{6}"
                : type === "url"
                ? "(https?:\\/\\/|www\\.).*"
                : undefined
            }
            readOnly={readOnly}
            min={min}
            max={max}
            step={step}

      onInvalid={(e) => {
    if (required && !value) {
      e.target.setCustomValidity(`${label} is required`);
    } else if (type === "url" && value && !isUrlValid) {
      e.target.setCustomValidity(
        `${label} must start with https://, http://, or www.`
      );
    } else if (name === "pincode" && value && !isPincodeValid) {
      e.target.setCustomValidity("Please enter a valid 6-digit pincode");
    }
  }}
  onInput={(e) => e.target.setCustomValidity("")} // reset when user types
          />



          {/* ✅ Show errors */}
          {type === "url" && value && !isUrlValid && (
            <small className="text-danger">
              Please enter a valid URL starting with{" "}
              <b>https://</b>, <b>http://</b>, or <b>www.</b>
            </small>
          )}
          {name === "pincode" && value && !isPincodeValid && (
            <small className="text-danger">
              Please enter a valid 6-digit pincode
            </small>
          )}

          {showCounter && (
            <div className="d-flex justify-content-between">
              <small className="text-muted">
                {value?.length || 0}/{maxLength}
              </small>
              {value?.length >= maxLength && (
                <small className="text-danger">
                  Max {maxLength} characters allowed
                </small>
              )}
            </div>
          )}
          {error && <small className="text-danger">{error}</small>}
        </>
      )}
    </Form.Group>
  );
}

export default Form_input;
