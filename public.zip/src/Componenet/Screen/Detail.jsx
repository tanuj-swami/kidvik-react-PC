import React from 'react'

function Detail() {
  return (
   <>
   <h1>Coming soon</h1>
   </>
  )
}

export default Detail