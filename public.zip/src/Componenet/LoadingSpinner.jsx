import React from "react";

export default function LoadingSpinner() {
  return (
    <>
    {/* <div style={{ textAlign: "center", padding: "2rem" }}>
      <p>Loading...</p>
    </div> */}
    </>
  );
}
