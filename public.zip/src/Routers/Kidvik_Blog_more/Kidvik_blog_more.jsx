import React from 'react'
import Blog from '../../Pages/Blog/Blog'

function Kidvik_blog_more() {
  return (
<>
<Blog/>

</>
)
}

export default Kidvik_blog_more