import React from 'react'
import Kidvik_Event from '../../Pages/Kidvik_Event/Kidvik_Event'

function Kidvik_event_more() {
  return (
   <>
   <Kidvik_Event/>
   
   </>
  )
}

export default Kidvik_event_more