import React from 'react'
import Kidvik_programe from '../../Pages/Kidvik_Program/Kidvik_programe'

function Kidvik_program_more() {
  return (
<>
<Kidvik_programe/>

</>
  )
}

export default Kidvik_program_more