import React from 'react'
import Testimonials from '../../Pages/Testimonials/Testimonials'

function Kidvik_testimonial_more() {
  return (
<>
<Testimonials/>
</>
)
}

export default Kidvik_testimonial_more