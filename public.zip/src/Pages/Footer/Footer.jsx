import React from "react";
import { Heart, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { FaApple, } from "react-icons/fa";
import { SiGoogleplay } from "react-icons/si";
import CopyRight from "./CopyRight";

const Footer = () => {
  return (
    <footer className="text-light pt-5" style={{ background: "black" }}>
      <div className="container ">

        <div className="row g-4 mb-5">

          {/* Brand */}
          <div className="col-12 col-md-6 col-lg-3 text-center text-lg-start">
            <img 
              src="/img/logo/Kidvik_Final_logo01.jpg.png" 
              alt="Kidvik Logo" 
              className="img-fluid mb-2" 
              style={{ maxWidth: '150px', height: 'auto' }}
            />
            <p className="text-light-50">Trusted Parenting Companion</p>

            <div className="d-flex justify-content-center justify-content-lg-start gap-2 mt-3">
              {[Facebook, Twitter, Instagram, Linkedin].map((Icon, idx) => (
                <a
                  href="#"
                  key={idx}
                  className="btn btn-outline-light btn-sm p-2 d-flex align-items-center justify-content-center"
                  style={{ transition: 'all 0.3s ease' }}
                  onMouseEnter={e => e.currentTarget.style.backgroundColor = 'white'}
                  onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}
                >
                  <Icon className="w-4 h-4 text-black" />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div className="col-12 col-md-6 col-lg-3">
            <h5 className="fw-bold mb-3 text-white">Services</h5>
            <ul className="list-unstyled">
              {["Schools & Education", "Healthcare & Doctors", "Daycare & Childcare", "Activities & Classes", "Kids Essentials", "Therapy & Development"].map((item, index) => (
                <li key={index} className="mb-2">
                  <a href="#" className="text-white text-decoration-none">{item}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company + Download Buttons */}
          <div className="col-12 col-md-6 col-lg-3">
            <h5 className="fw-bold mb-3 text-white">Company</h5>
            <ul className="list-unstyled mb-3">
              {["About Us", "Partner with Us"].map((item, index) => (
                <li key={index} className="mb-2">
                  <a href="#" className="text-white text-decoration-none">{item}</a>
                </li>
              ))}
            </ul>

            {/* <p className="text-white mb-2">Download Our App</p> */}

<div className="d-flex flex-wrap align-items-center gap-2">
  {/* App Store badge */}
  <a
    href="#"
    className="d-flex align-items-center text-decoration-none justify-content-start p-2"
    style={{
      color: "#000",
      background: "#fff",
      borderRadius: 8,
      transition: "transform .2s ease",
    }}
    onMouseEnter={(e) => (e.currentTarget.style.transform = "translateY(-3px)")}
    onMouseLeave={(e) => (e.currentTarget.style.transform = "translateY(0)")}
  >
    <FaApple size={28} className="me-2" />
    <div style={{ lineHeight: 1 }}>
      <div style={{ fontSize: 11 }}>Download on the</div>
      <div style={{ fontSize: 17, fontWeight: "600" }}>App Store</div>
    </div>
  </a>

  {/* Google Play badge */}
  <a
    href="#"
    className="d-flex align-items-center text-decoration-none justify-content-start p-2"
    style={{
      color: "#000",
      background: "#fff",
      borderRadius: 8,
      transition: "transform .2s ease",
    }}
    onMouseEnter={(e) => (e.currentTarget.style.transform = "translateY(-3px)")}
    onMouseLeave={(e) => (e.currentTarget.style.transform = "translateY(0)")}
  >
    <img
      src="/img/logo/playstoreimg-removebg-preview.png"
      alt="Google Play"
      className="me-2"
      style={{
        width: "28px",
        height: "28px",
        objectFit: "contain",
      }}
    />
    <div style={{ lineHeight: 1 }}>
      <div style={{ fontSize: 11 }}>GET IT ON</div>
      <div style={{ fontSize: 17, fontWeight: "600" }}>Google Play</div>
    </div>
  </a>
</div>




          </div>

          {/* Contact */}
          <div className="col-12 col-md-6 col-lg-3">
            <h5 className="fw-bold mb-3 text-white">Contact</h5>
            <ul className="list-unstyled">
              <li className="d-flex align-items-center mb-2">
                <Mail className="me-2 text-white" /> connect@kidvik.com
              </li>
              <li className="d-flex align-items-center mb-2">
                <Phone className="me-2 text-white" /> 9876567876
              </li>
              <li className="d-flex align-items-center mb-2">
                <MapPin className="me-2 text-white mt-1" />
                <span>
                  Mumbai, Maharashtra<br />
                  
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
      <CopyRight/>

      </div>
    </footer>
  );
};

export default Footer;
