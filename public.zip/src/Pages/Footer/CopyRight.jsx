import React from 'react'

function CopyRight() {
  return (
   <>
   <div className="border-top border-light-25 pt-3 pb-2">
          <div className="d-flex flex-column flex-md-row justify-content-between align-items-center">
            <small className="text-light-50 mb-2 mb-md-0">© 2024 Kidvik. All rights reserved. Made with ❤️ for families.</small>
            <div className="d-flex gap-3">
              <a href="#" className="text-light-50 text-decoration-none">Privacy Policy</a>
              <a href="#" className="text-light-50 text-decoration-none">Terms of Service</a>
              <a href="#" className="text-light-50 text-decoration-none">Cookie Policy</a>
            </div>
          </div>
        </div>

   
   </>
  )
}

export default CopyRight