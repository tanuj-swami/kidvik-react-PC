import React, { useEffect, useState } from "react";
import { Loading } from "../../Helper/Loader";
import GlobalSlider from "../../GlobalOwlSlider/GlobalOwlSlider ";
import { BASE_URL } from "../../Helper/Base_Url";
import Top_Heading from "../../Helper/Top_Heading";
import "../Blog/Blog.css"
import { NavLink } from "react-router-dom";
function Blog() {
  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${BASE_URL}/BlogPost`)
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data?.data)) {
          setBlogs(data.data);
        }
      })
      .catch((err) => console.error("Error fetching blogs:", err))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <Loading />;
  }

  if (blogs.length === 0) {
    return (
      <div className="text-center py-5">
        <h4>No blog posts found</h4>
      </div>
    );
  }

  return (
    <div className="container-fluid blog py-2">
      <div className="container py-2">
        {/* <div
          className="mx-auto text-center wow fadeIn"
          data-wow-delay="0.1s"
          style={{ maxWidth: 600 }}
        >
          <h4 className="text-primary mb-4 border-bottom border-primary border-2 d-inline-block p-2 title-border-radius">
            Latest News &amp; Blog
          </h4>
          <h1 className="mb-5 display-3">Insights for Smart Parenting</h1>
        </div> */}
        <Top_Heading subtitile="Latest News &amp; Blog" titile="Insights for Smart Parenting" />

        <GlobalSlider >
          {blogs.map((item, idx) => (
            <div key={item.blog_id || idx} className="p-2">
              <div className="blog-item rounded-bottom">
                <div className="blog-img overflow-hidden position-relative img-border-radius">
                  <img
                    src={`${BASE_URL}${item.image}`}
                    className="img-fluid w-100"
                    alt={item.title}
                  />
                </div>
                <div className="d-flex justify-content-between px-4 py-3 bg-light border-bottom border-primary blog-date-comments">
                  <small className="text-dark">
                    <i className="fas fa-calendar me-1 text-dark" />{" "}
                    {item.Date
                      ? new Date(item.Date).toLocaleDateString("en-GB", {
                        day: "2-digit",
                        month: "short",
                        year: "numeric",
                      })
                      : "No Date"}
                  </small>
                  {/* <small className="text-dark">
                    <i className="fas fa-comment-alt me-1 text-dark" /> Comments (0)
                  </small> */}
                </div>
                <div className="blog-content d-flex align-items-center px-4 py-3 bg-light">
                  <div className="overflow-hidden rounded-circle border border-primary">
                    <img
                      src={'/img/kidvik_school_img/user_image.jpg '}
                      className="img-fluid rounded-circle p-2"
                      alt={item.keywords || "Author"}
                      style={{
                        width: 70,
                        height: 70,
                        borderStyle: "dotted",
                        borderColor: "var(--bs-primary)",
                      }}
                    />
                  </div>
                  <div className="ms-3">
                    <h5 className="text-primary">{item.keywords || "Unknown Author"}</h5>
                    <p className="text-muted">{item?.author?.username}</p>
                  </div>
                </div>

                <div className="px-2 pb-2 bg-light rounded-bottom">
                  <div className="blog-text-inner">
                    <a href="#" className="h4">
                      {item.title}
                    </a>
                    <p
                      className="mt-2 mb-3"
                      dangerouslySetInnerHTML={{
                        __html:
                          item.content && item.content.length > 120
                            ? item.content.slice(0, 120) + "..."
                            : item.content || "",
                      }}
                    ></p>
                  </div>


                  <div className="text-center">
                    <NavLink
                      to={`/blog/${item.slug}`}
                      className="btn btn-primary text-white px-4 py-2 mb-3 btn-border-radius"
                    >
                      View Details
                    </NavLink>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </GlobalSlider>

      </div>
    </div>
  );
}

export default Blog;
