import React, { useEffect, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { BASE_URL } from "../../Helper/Base_Url";

function Navbar_Menu() {
  const [categories , setCategories] = useState([]);

  useEffect(() => {
    // Fetch both APIs
    Promise.all([
      fetch(`${BASE_URL}/sub_category/`).then((res) => res.json()),
      fetch(`${BASE_URL}/sub_category_detail/`).then((res) => res.json()),
    ])
      .then(([subCats, subCatDetails]) => {
        const subCatDetailsMap = subCatDetails.data.reduce((acc, item) => {
          const subId = item.sub_category.id;
          if (!acc[subId]) acc[subId] = [];
          acc[subId].push(item); // store sub-subcategories under subcategory id
          return acc;
        }, {});

        const grouped = subCats.data.reduce((acc, sub) => {
          const catId = sub.category.id;
          if (!acc[catId]) {
            acc[catId] = {
              ...sub.category,
              subcategories: [],
            };
          }
          // attach sub-subcategories if exist
          const subWithDetails = {
            ...sub,
            subcategories: subCatDetailsMap[sub.id] || [],
          };

          acc[catId].subcategories.push(subWithDetails);
          return acc;
        }, {});

        setCategories(Object.values(grouped));
      })
      .catch((err) => console.error(err));
  }, []);

const renderSubcategories = (subs, isDetail = false) => {
  return subs.map((sub) => {
    if (sub.subcategories && sub.subcategories.length > 0) {
      return (
        <div className="dropdown-submenu" key={sub.id}>
          <a
            href="#"
            className="dropdown-item dropdown-toggle d-flex align-items-center gap-2"
            data-bs-toggle="dropdown"
          >
            <img
              src={`${BASE_URL}${sub.icon_img}`}
              alt={sub.name}
              style={{
                height: "30px",
                width: "30px",
                objectFit: "contain",
              }}
            />
            <span>{sub.name}</span>
          </a>

          <div className="dropdown-submenu">
            {/* 👇 when going deeper, pass true */}
            {renderSubcategories(sub.subcategories, true)}
          </div>
        </div>
      );
    } else {
      return (
        <NavLink
          to={`subcategory/${sub.slug}`}
          state={{ 
            type: isDetail ? "sub_categorydetail" : "sub_category", 
             category_id: sub.category?.id, 
             sub_category_id: sub?.id, 
             sub_category_Detail_id: isDetail ? sub?.id : ""
          }}
          className="dropdown-item"
          key={sub.id}
        >
          <img
            src={`${BASE_URL}${sub.icon_img}`}
            alt={sub.name}
            style={{
              height: "30px",
              width: "30px",
              objectFit: "contain",
            }}
          />{" "}
          <span>{sub.name}</span>
        </NavLink>
      );
    }
  });
};


  return (
    <div className="navbar-nav mx-auto">
      <Link to="/" className="nav-item nav-link">
        Home
      </Link>

      {categories.map((cat) => (
        <div key={cat.id} className="nav-item dropdown">
          <a href="#" className="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                     {cat.name}
          </a>

          {cat.subcategories && cat.subcategories.length > 0 && (
            <div className="dropdown-menu m-0 bg-primary">
               {renderSubcategories(cat.subcategories)}
            </div>
          )}
        </div>
      ))}

      <NavLink to="/contact-us" className="nav-item nav-link">
           Contact
      </NavLink>
    </div>
  );
}

export default Navbar_Menu;
