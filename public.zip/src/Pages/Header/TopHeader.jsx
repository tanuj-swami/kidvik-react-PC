import React, { useEffect, useState } from 'react';
import { BASE_URL } from '../../Helper/Base_Url';
import { Link } from 'react-router-dom'
import { useLogin } from '../../Contaxt/Login_Contaxt';
function TopHeader() {


const { topbarData  } = useLogin();
  // if (!topbarData) {
  //   return null; 
  // }
console.log("topbarData",topbarData)
  return (
    <div
      className="container-fluid topbar bg-primary d-none d-lg-block py-2"
      style={{ borderRadius: '0 40px' }}
    >
      <div className="d-flex justify-content-between">

        <div className="top-info ps-2">
          {topbarData?.topbar_address && (
            <small className="me-3">
              <i className="fas fa-map-marker-alt me-2 text-white " />
              <a href="#" className="text-white">
                {topbarData?.topbar_address}
              </a>
            </small>
          )}

          {topbarData?.topbar_mail && (
            <small className="me-3">
              <i className="fas fa-envelope me-2 text-white" />
              <a
                to={`mailto:${topbarData?.topbar_mail}`}
                className="text-white"
              >
                {topbarData?.topbar_mail}
              </a>
            </small>
          )}

          {topbarData?.topbar_phoneno && (
            <small className="me-3">
              <i className="fas fa-phone me-2 text-white" style={{ transform: 'scaleX(-1)' }}/>
              <a
                href={`tel:${topbarData?.topbar_phoneno}`}
                className="text-white"
              >
                {topbarData?.topbar_phoneno}
              </a>
            </small>
          )}
        </div>

        
        {topbarData?.topbar_text && (
      <div className="text-white text-center mx-auto d-flex align-items-center gap-2">
        <span>{topbarData?.topbar_text}</span>
        {topbarData?.Button_text && (
          <a
            href={topbarData?.Button_link || '#'}
            className="btn btn-sm btn-light rounded-pill px-3"
          >
            {topbarData?.Button_text}
          </a>
        )}
      </div>
    )}

        <div className="top-link pe-2">
          {topbarData?.topbar_facebook && (
            <a
              href={topbarData?.topbar_facebook}
              className="btn btn-light btn-sm-square rounded-circle bg-danger"
              target="_blank"
              rel="noreferrer"
            >
              <i className="fab fa-facebook-f text-white" />
            </a>
          )}

          {topbarData?.topbar_twitter && (
            <a
              href={topbarData?.topbar_twitter}
              className="btn btn-light btn-sm-square rounded-circle bg-danger"
              target="_blank"
              rel="noreferrer"
            >
              <i className="fab fa-twitter text-white" />
            </a>
          )}

          {topbarData?.topbar_instagram && (
            <a
              href={topbarData?.topbar_instagram}
              className="btn btn-light btn-sm-square rounded-circle bg-danger"
              target="_blank"
              rel="noreferrer"
            >
              <i className="fab fa-instagram text-white" />
            </a>
          )}

          {topbarData?.topbar_linkedin && (
            <a
              href={topbarData?.topbar_linkedin}
              className="btn btn-light btn-sm-square rounded-circle me-0 bg-danger"
              target="_blank"
              rel="noreferrer"
            >
              <i className="fab fa-linkedin-in text-white" />
            </a>
          )}
        </div>


      </div>
    </div>

    
//  <div className="container-fluid topbar bg-primary d-none d-lg-block py-2"
//   style={{borderRadius: '0 40px'}}
//   >
//   <div className="d-flex justify-content-between">
//     <div className="top-info ps-2">
//       <small className="me-3"><i className="fas fa-map-marker-alt me-2 text-secondary" /> <a href="#" className="text-white"> Mumbai, Maharashtra</a></small>
//       <small className="me-3"><i className="fas fa-envelope me-2 text-secondary" /><a href="mailto:connect@kidvik.com" className="text-white">connect@kidvik.com</a></small>
//     </div>
//     <div className="top-link pe-2">
//       <a href className="btn btn-light btn-sm-square rounded-circle"><i className="fab fa-facebook-f text-secondary" /></a>
//       <a href className="btn btn-light btn-sm-square rounded-circle"><i className="fab fa-twitter text-secondary" /></a>
//       <a href className="btn btn-light btn-sm-square rounded-circle"><i className="fab fa-instagram text-secondary" /></a>
//       <a href className="btn btn-light btn-sm-square rounded-circle me-0"><i className="fab fa-linkedin-in text-secondary" /></a>
//     </div>
//   </div> 
// </div>



  );
}

export default TopHeader;
