import React from "react";
import styled from "styled-components";
import { GraduationCap, Heart, Users, Palette, CheckCircle  } from "lucide-react";
import { FaRegCalendarAlt } from "react-icons/fa";
const categories = [
  {
    icon: GraduationCap,
    title: "Schools",
    bgColor: "#d1fae5", 
    iconColor: "text-success",
    checkColor: "bg-success"
  },
  {
    icon: Heart,
    title: "Hospitals",
    bgColor: "#fee2e2", 
    iconColor: "text-danger",
    checkColor: "bg-danger"
  },
 {
  icon: FaRegCalendarAlt,   
  title: "Upcoming Events",
  bgColor: "#fef3c7", // light orange/yellow (event vibe)
  iconColor: "text-warning", // Bootstrap warning = orange
  checkColor: "bg-warning"
},

  {
    icon: Palette,
    title: "Activities",
    bgColor: "#d1fae5", // green-light
    iconColor: "text-success",
    checkColor: "bg-success"
  }
];


// Styled component for hover effect and checkmark positioning
const CategoryCard = styled.div`
  position: relative;
  border-radius: 1rem;
  padding: 1.5rem;
  text-align: center;
  cursor: pointer;
  transition: transform 0.3s, box-shadow 0.3s;

  /* Light background based on props */
  background-color: ${(props) => props.bg || "#d1fae5"}; /* default green-light */

  &:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 20px rgba(0,0,0,0.15);
  }

  .checkmark {
    position: absolute;
    top: 0.75rem;
    right: 0.75rem;
    width: 1.5rem;
    height: 1.5rem;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
  }

  svg {
    transition: transform 0.3s;
  }

  &:hover svg {
    transform: scale(1.1);
  }
`;


const Categories = () => {
  return (
    <section id="categories" className="py-5">
      <div className="container">
        <div className="row g-4">
          {categories.map((category, index) => {
            const Icon = category.icon;
            return (
              <div key={index} className="col-6 col-lg-3">
              <CategoryCard key={index} bg={category.bgColor}>
  <div className="mb-3">
    <Icon className={`w-12 h-12 ${category.iconColor}`} />
  </div>
  <h5 className="fw-semibold">{category.title}</h5>
  <div className={`checkmark ${category.checkColor}`}>
    <CheckCircle className="w-4 h-4" />
  </div>
</CategoryCard>

              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Categories;
