import React from "react";
import { Building2, Award, HandHeart, TrendingUp, CheckCircle, ArrowRight } from "lucide-react";
import TopHeadingBar from "../../Helper/TopHeadingBar";
import { style } from "framer-motion/client";
import styled from "styled-components";
const partnerBenefits = [
  {
    icon: Building2,
    title: "Increase Visibility",
    description: "Get discovered by thousands of parents actively looking for services like yours in your area.",
    color: "text-primary",
    bgColor: "bg-primary-light"
  },
  {
    icon: Award,
    title: "Build Trust",
    description: "Showcase your credentials, certifications, and positive reviews to build credibility with parents.",
    color: "text-purple",
    bgColor: "bg-purple-light"
  },
  {
    icon: HandHeart,
    title: "Connect with Families",
    description: "Directly engage with parents, answer their questions, and build lasting relationships with families.",
    color: "text-success",
    bgColor: "bg-success-light"
  },
  {
    icon: TrendingUp,
    title: "Grow Your Business",
    description: "Increase bookings, attract new customers, and grow your business with our targeted marketing tools.",
    color: "text-warning",
    bgColor: "bg-warning-light"
  }
];

const partnerTypes = [
  "Schools & Educational Institutions",
  "Healthcare Providers & Clinics",
  "Daycare & Childcare Centers",
  "Activity Centers & Classes",
  "Retail & Kids Essential Stores",
  "Therapy & Development Centers"
];

const Partners = () => {
  return (
    <section className="py-5 bg-light">
      <div className="container">

        {/* Header */}
        {/* <div className="text-center mb-5">
          <span className="badge bg-info text-dark mb-3 d-inline-flex align-items-center gap-2">
            <HandHeart className="me-1" /> Partner with Us
          </span>
          <h2 className="fw-bold mb-3">Join the Kidvik <span className="text-primary d-block">Partner Network</span></h2>
          <p className="text-secondary mb-3">Connect with thousands of parents in your area. Showcase your services, build trust, and grow your business with Kidvik's trusted platform.</p>

          <div className="d-flex flex-wrap justify-content-center gap-3 text-secondary small">
            <div className="d-flex align-items-center gap-1">
              <CheckCircle className="text-success" /> Free to Join
            </div>
            <div className="d-flex align-items-center gap-1">
              <CheckCircle className="text-success" /> No Setup Fees
            </div>
            <div className="d-flex align-items-center gap-1">
              <CheckCircle className="text-success" /> Easy Management
            </div>
          </div>
        </div> */}
        <TopHeadingBar icon={<HandHeart />} Topheading="Partner with Us" firstHeading="Join the Kidvik" secondHeading="Partner Network" description="Connect with thousands of parents in your area. Showcase your services, build trust, and grow your business with Kidvik's trusted platform." />

        {/* Benefits Grid */}
        <div className="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4 mb-5">
          {partnerBenefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
               <Card  key={index} > 
              <div  className="col">
                <div className="card h-100 border-1 shadow-lg rounded-2 text-center p-3">
                  <div className={`d-flex align-items-center justify-content-center rounded-3 mb-3`} style={{ width: '64px', height: '64px', backgroundColor: benefit.bgColor }}>
                    <Icon className={`fs-5 ${benefit.color}`} />
                  </div>
                  <h5 className="fw-semibold">{benefit.title}</h5>
                  <p className="text-black small">{benefit.description}</p>
                </div>
              </div>
              </Card>
            );
          })}
        </div>

        {/* Partner Types */}
        <div className="bg-white rounded-3 p-4 mb-5 shadow-sm">
          <h4 className="fw-bold text-center mb-4">Who Can Partner with Kidvik?</h4>
          <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-3">
            {partnerTypes.map((type, index) => (
              <Card  key={index} > 
              <div  className="col">
                <div className="d-flex align-items-center bg-light rounded-2 p-3 shadow-sm gap-2">
                  <div className="bg-primary rounded-circle me-2" style={{ width: '8px', height: '8px' }}></div>
                  <span className="fw-medium">{type}</span>
                </div>
              </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="row text-center mb-5">
          <div className="col-md-4 mb-3 mb-md-0">
            <h3 className="fw-bold text-primary">2,000+</h3>
            <p className="text-secondary">Active Partners</p>
          </div>
          <div className="col-md-4 mb-3 mb-md-0">
            <h3 className="fw-bold text-warning">150%</h3>
            <p className="text-secondary">Average Growth</p>
          </div>
          <div className="col-md-4">
            <h3 className="fw-bold text-success">4.9/5</h3>
            <p className="text-secondary">Partner Satisfaction</p>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <div className="p-5 bg-primary-light rounded-3 shadow-lg">
            <h4 className="fw-bold text-primary mb-3">Ready to Grow Your Business?</h4>
            <p className="text-primary mb-4">Join thousands of trusted service providers who are already connecting with families through Kidvik. It's free to get started!</p>
            <div className="d-flex flex-column flex-sm-row justify-content-center gap-3">
              <button className="btn btn-primary d-flex align-items-center gap-2">
                <Building2 className="me-1" /> Become a Partner <ArrowRight className="ms-1" />
              </button>
              <button className="btn btn-primary">Learn More</button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

const Card = styled.div`

  transition: transform 0.3s ease, box-shadow 0.3s ease;
  &:hover {
    transform: translateY(-5px);
    // box-shadow: 1px 8px 12px rgba(0, 0, 0, 0.2);
  }
`;        

export default Partners;
